# Test Pyramid in Spring Boot

A simple Spring Boot application which serves a REST API for demonstrating testing on different levels of the test pyramid. 

## Run

From your IDE or via the command line

```bash
$ ./mvnw spring-boot:run
# or
$ mvn spring-boot:run
```
