# Maven Testing Starter Project

Project to demonstrate the use of Maven for using Java testing tools.


